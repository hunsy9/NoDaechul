package com.cloudcomputing.nodaechul.user.exception;

public class ActivationFailedException extends RuntimeException{
    public ActivationFailedException(String message) {
        super(message);
    }
}
