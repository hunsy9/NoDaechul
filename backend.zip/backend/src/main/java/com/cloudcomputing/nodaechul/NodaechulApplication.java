package com.cloudcomputing.nodaechul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NodaechulApplication {

	public static void main(String[] args) {
		SpringApplication.run(NodaechulApplication.class, args);
	}

}
