package com.cloudcomputing.nodaechul.user.exception;

public class LoginException extends RuntimeException{
    public LoginException(String message) {
        super(message);
    }
}
