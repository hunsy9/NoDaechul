package com.cloudcomputing.nodaechul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NodaechulApplicationTests {

	@Test
	void contextLoads() {
	}

}
